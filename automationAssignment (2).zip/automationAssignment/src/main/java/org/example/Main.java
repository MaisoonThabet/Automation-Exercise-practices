package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws InterruptedException {

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        //To Open Google
        driver.get("https://www.google.com/");
        Thread.sleep(2000);

        //To Navigate to Automation Exercise website
        driver.get("https://automationexercise.com/login");

        // To login using Username and Password

        driver.findElement(By.cssSelector("input[data-qa=\"login-email\"]")).sendKeys("Maisoon@test.com");
        driver.findElement(By.cssSelector("input[data-qa=\"login-password\"]")).sendKeys("123321");
        driver.findElement(By.cssSelector("button[data-qa=\"login-button\"]")).click();

       // To View Products list
        driver.findElement(By.cssSelector("a[href=\"/products\"]")).click();
        System.out.println("Second Product Name is: " + driver.findElement(By.cssSelector("div[class=\"col-sm-4\"]:nth-child(16) p")).getText());
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("div[class=\"col-sm-4\"]:nth-child(16)")).click();

        // To View Product Details
        driver.findElement(By.cssSelector("a[href=\"/product_details/16\"]")).click();

        Thread.sleep(2000);
       // To Remove Quantity
        WebElement quantity = driver.findElement(By.cssSelector("input[id=\"quantity\"]"));
        quantity.clear();

        // To Add Quantity
        driver.findElement(By.cssSelector("input[id=\"quantity\"]")).sendKeys("5");

        //To Add Item to Cart
        driver.findElement(By.cssSelector("button[class=\"btn btn-default cart\"]")).click();

        Thread.sleep(3000);
        driver.findElement(By.cssSelector("a[href=\"/view_cart\"] u")).click();
        Thread.sleep(3000);
        System.out.println("Product Name: " + driver.findElement(By.cssSelector("a[href=\"/product_details/16\"]")).getText());
        System.out.println("Product Total Price: " + driver.findElement(By.cssSelector("p[class=\"cart_total_price\"]")).getText());

        // To Proceed Checkout
        driver.findElement(By.cssSelector("a[class=\"btn btn-default check_out\"]")).click();

        // To Place order
        driver.findElement(By.cssSelector("textarea[class=\"form-control\"]")).sendKeys("Maisoon Thabet");
        Thread.sleep(4000);
        driver.findElement(By.cssSelector("a[class=\"btn btn-default check_out\"]")).click();

        // Payment Page
        driver.findElement(By.cssSelector("input[name=\"name_on_card\"]")).sendKeys("Maisoon Thabet Test");
        driver.findElement(By.cssSelector("input[data-qa=\"card-number\"]")).sendKeys("1234554321");
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("input[data-qa=\"cvc\"]")).sendKeys("123");
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("input[data-qa=\"expiry-month\"]")).sendKeys("10");
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("input[data-qa=\"expiry-year\"]")).sendKeys("2030");
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[data-qa=\"pay-button\"]")).click();
        Thread.sleep(5000);



        //Success Screen
       /* WebElement successMessage = driver.findElement(By.id("Order Placed!"));
        System.out.println(driver.findElement(By.id("Order Placed!")).getText());
*/
        driver.quit();


    }
}
